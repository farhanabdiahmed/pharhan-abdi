﻿namespace Assignment_fat_and_colories
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculating_percentage = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.fatgramstextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Result = new System.Windows.Forms.Label();
            this.total_coloriestextBox = new System.Windows.Forms.TextBox();
            this.clear = new System.Windows.Forms.Button();
            this.Exist = new System.Windows.Forms.Button();
            this.low = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // calculating_percentage
            // 
            this.calculating_percentage.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.calculating_percentage.Location = new System.Drawing.Point(313, 557);
            this.calculating_percentage.Name = "calculating_percentage";
            this.calculating_percentage.Size = new System.Drawing.Size(107, 68);
            this.calculating_percentage.TabIndex = 3;
            this.calculating_percentage.Text = "c&alculate percentage of colories";
            this.calculating_percentage.UseVisualStyleBackColor = false;
            this.calculating_percentage.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(208, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter number of fat grams";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // fatgramstextBox
            // 
            this.fatgramstextBox.Location = new System.Drawing.Point(516, 112);
            this.fatgramstextBox.Name = "fatgramstextBox";
            this.fatgramstextBox.Size = new System.Drawing.Size(100, 26);
            this.fatgramstextBox.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(214, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter number total colories";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Result
            // 
            this.Result.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Result.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Result.ForeColor = System.Drawing.SystemColors.Window;
            this.Result.Image = global::Assignment_fat_and_colories.Properties.Resources.alshaafi;
            this.Result.Location = new System.Drawing.Point(313, 392);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(303, 83);
            this.Result.TabIndex = 1;
            this.Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // total_coloriestextBox
            // 
            this.total_coloriestextBox.Location = new System.Drawing.Point(516, 157);
            this.total_coloriestextBox.Name = "total_coloriestextBox";
            this.total_coloriestextBox.Size = new System.Drawing.Size(100, 26);
            this.total_coloriestextBox.TabIndex = 1;
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.clear.Location = new System.Drawing.Point(455, 568);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 46);
            this.clear.TabIndex = 4;
            this.clear.Text = "C&lear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.button2_Click);
            // 
            // Exist
            // 
            this.Exist.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Exist.Location = new System.Drawing.Point(579, 557);
            this.Exist.Name = "Exist";
            this.Exist.Size = new System.Drawing.Size(75, 46);
            this.Exist.TabIndex = 5;
            this.Exist.Text = "E&xist";
            this.Exist.UseVisualStyleBackColor = false;
            this.Exist.Click += new System.EventHandler(this.button3_Click);
            // 
            // low
            // 
            this.low.AutoSize = true;
            this.low.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.low.Location = new System.Drawing.Point(381, 334);
            this.low.Name = "low";
            this.low.Size = new System.Drawing.Size(121, 24);
            this.low.TabIndex = 2;
            this.low.Text = "low fat or no";
            this.low.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox1.Location = new System.Drawing.Point(154, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(571, 276);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "fat and colories";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(859, 635);
            this.Controls.Add(this.low);
            this.Controls.Add(this.total_coloriestextBox);
            this.Controls.Add(this.fatgramstextBox);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Exist);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.calculating_percentage);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Fat and colories";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculating_percentage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox fatgramstextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Result;
        private System.Windows.Forms.TextBox total_coloriestextBox;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button Exist;
        private System.Windows.Forms.CheckBox low;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

