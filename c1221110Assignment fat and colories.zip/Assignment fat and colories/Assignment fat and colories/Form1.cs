﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_fat_and_colories
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // declaring variables
            double fat_grams, total_colories, colories_from_fat, perentage_of_colories_from_fat;
            String low_fat = " ";
            // initializing the fat grams  to fatgram_textbox

            fat_grams = double.Parse(fatgramstextBox.Text);
          

            // initializing the total colories  to totalcolories_textbox
           total_colories = double.Parse(total_coloriestextBox.Text);
           // validating if fat_grams and total_colories is not less than 0

           if (fat_grams < 0 || total_colories <0)
           {
               MessageBox.Show(" Enter a positive number");
               return;
           }
            else{
               // continue
            }

            // initializing the colories from fat
           colories_from_fat = fat_grams * 9;

           // validating  if colories_from_fat greater than total_colories
           if (colories_from_fat > total_colories) {
               MessageBox.Show(" either the calories or fat  grams were incorrectly entered ");
               return;
           }


           // initializing perentage of colories from fat 
           perentage_of_colories_from_fat = (colories_from_fat / total_colories) ;

            // validating checkbox 
            if(low.Checked){
              if(perentage_of_colories_from_fat *100 <30){
                  low_fat = "low fat";
              }

            }

            // Displaying the result
           Result.Text = "perentage of colories from fat is : " + perentage_of_colories_from_fat.ToString("p0")+low_fat;
           // focusing the  fatgramstextBox or textbox1
           fatgramstextBox.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fatgramstextBox.Text = "";
            total_coloriestextBox.Clear();
            Result.Text = "";

            low.Checked = false;
           
            fatgramstextBox.Focus();


        }
    }
}
